package Bakery;

import java.util.Scanner;

public class Pastry extends Cake
{
Pastry(String name, float price) {
		super(name, price);
		// TODO Auto-generated constructor stub
	}
@Override
void Display() {
	// TODO Auto-generated method stub
	
	Scanner sc=new Scanner (System.in);
	//super.Display();
//	System.out.println("Enter Pastry name:");
//	String nm=sc.nextLine();
//	System.out.println("Enter Price:");
//	float price=sc.nextFloat();
	System.out.println(name+":"+" Rs. "+price+"per piece");
	
}
@Override
	public String getName() {
		// TODO Auto-generated method stub
		return super.getName();
	}
@Override
	public float getPrice() {
		// TODO Auto-generated method stub
		return super.getPrice();
	}
@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		super.setName(name);
	}
@Override
		public void setPrice(float price) {
			// TODO Auto-generated method stub
			super.setPrice(price);
		}


}