package Bakery;

import java.util.Scanner;

public class Cake {

		String name;
		float price;
		
		Cake(String name,float price)
		{
			this.name=name;
			this.price=price;
		}
		
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public float getPrice() {
			return price;
		}

		public void setPrice(float price) {
			this.price = price;
		}
		
		void Display()
		{
			Scanner sc=new Scanner(System.in);
			
//			System.out.println("Enter Cake Name:");
//			name=sc.nextLine();
//			
//			System.out.println("Enter Price:");
//			price=sc.nextFloat();
			System.out.println(name+":"+" Rs. "+price+" per pound");
		}
		
	}


