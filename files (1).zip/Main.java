package Bakery;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("     Today's Special Menu   ");
		System.out.println("__________________________________");
		
//		
//		String pastry[]=new String [2];
		
//		for(int i=0;i<2;i++)
//		{
//			p1.Display();
//		}
		System.out.println("Special Cakes");
		System.out.println("__________________________________");		
		Cake c1=new Cake("Choclate Brownie",2000);
		Cake c2=new Cake("Choclate Maple",3000);	
		
		
		c1.Display();
		c2.Display();
		System.out.println();
		System.out.println("Special Pastries");
		System.out.println("__________________________________");		
		Pastry p1=new Pastry("Black Forest",350);
		Pastry p2=new Pastry("Choco Truffle",450);

		p1.Display();
		p2.Display();
	}

}
